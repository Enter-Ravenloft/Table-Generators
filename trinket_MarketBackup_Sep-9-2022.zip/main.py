'''                                                               UPLOAD BUTTON ↗
READ ME, please :)

The following instructions require that you have a file named "marketGenerator.py"

Instructions: 
1. You will need to return back to this tab "main.py" after the next step.
    If you look straight up from the start of this line, you will see it.
2. Click on the 📤︎ button in the top right corner of the left pane to upload the 
    marketGenerator.py file 
3. Click the ▶ button in the top bar.
4. Copy the all of the output
4. Return to discord for the rest of the instructions.
  

If you have difficulties with this, ping Quincy on discord
or ask in #Helpers
''' 


from marketGenerator import *